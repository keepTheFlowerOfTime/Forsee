Definition Function 
---------------------------
non void 

function_type function_name (parametres)  (int x, char y) 
{
    commands;
    return x ;
}


void -> geriye değer döndürmeyen fonksiyonlar

void  (int x, char y) 
{
    commands;
    printf("asddsa");
}

* -> pointer döndüren

int * addr  (int x, char y) 
{
    commands;
    printf("asddsa");
}




int x (int a, int b)
{
    int sum =a+b;
    return sum;
}


int toplam (int a, int b)
{
    int sum =a+b;
    return sum;
}














main -> ana fonksiyon

Call Function 
---------------------------

function_type function_name (parametres)
{
    commands;
}



void main ()
{
    function_name(paramatres); 
}



