#include<stdio.h>










struct node
{
  char c;
  short int s;
};


struct node
{
  short int s;
  char c;
  int i;
};


struct node
{
  char c;
  double d;
  int i;
};


struct node
{
  double d;
  int i;
  char c;
};




